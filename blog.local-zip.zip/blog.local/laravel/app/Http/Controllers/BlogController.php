<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Post;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class BlogController extends Controller
{
	
	//показ всей ленты
	public function feed(){
		//обращение к таблицам
		$posts = Post::all();
		//получить авторов - пользователей, написавших хотя бы один пост
		$qry = 'SELECT users.id, users.name FROM tr2022_users AS users LEFT JOIN tr2022_posts AS posts ';
		$qry = $qry.'ON users.id = posts.author_id ';
		$qry = $qry.'GROUP BY users.id';
		$authors = DB::select($qry);
		//передача данных в представление для постов
		return view('pages.feed', [
			'posts' => $posts,
			'authors' => $authors,
		]);
	}

	//показ постов только из подписок
	public function subsPosts(){
		//
		$user_id = Auth::id();
		$qry = 'SELECT * FROM tr2022_posts LEFT JOIN tr2022_subscriptions AS subs ';	//откуда брать
		$qry = $qry.'ON tr2022_posts.author_id = subs.author_id ';					//как объединить
		$qry = $qry.'WHERE subs.user_id = '.Auth::id();						//как выбрать нужное
		$posts = DB::select($qry);
		//получить авторов на которых оформлена подписка
		//!!!! НЕ СДЕЛАЛ
		$qry = 'SELECT users.id, users.name FROM tr2022_users AS users LEFT JOIN tr2022_posts AS posts ';
		$qry = $qry.'ON users.id = posts.author_id ';
		$qry = $qry.'GROUP BY users.id';
		$authors = DB::select($qry);		
		//передача данных в представление для постов
		return view('pages.feed', [
			'posts' => $posts,
			'authors' => $authors,
		]);
	}
	
	//показать выбранный пост
	public function getPost($post_id){
		$post = Post::where('id', $post_id)->first();
		return view('pages.show-post', [
			'post' => $post,
		]);
	}
	
	//создать новый пост
	public function newPost(){
		return view('pages.new-post');
	}
	
	//сохранить пост
	public function savePost(Request $request){
		//извлечение данных из POST-запроса
		$author_id = Auth::id();
		$title = $request->input('title');
		$descr = $request->input('descr');
		$fulltext = $request->input('fulltext');

		//сохранение поста в таблице posts
		$qry = 'INSERT INTO tr2022_posts (`author_id`, `title`, `descr`, `fulltext`) VALUES (?, ?, ?, ?)';
		$users = DB::insert($qry, [$author_id, $title, $descr, $fulltext]);
		return view('pages.save-post');
	}
	
	//выход пользователя из web-приложения
	public function logout(Request $request)
	{
		Auth::logout();
		$request->session()->invalidate();
		$request->session()->regenerateToken();
		return redirect()->route('home');
	}
	
	//оформить подписку
	public function subscribed(Request $request){
		//на кого подписывается
		$author_id = $request->input('author_id');
		//кто подписывается
		$user_id = Auth::id();
		//проверка, не оформлена подписка ранее
		$qry = 'SELECT `author_id`, `user_id` FROM tr2022_subscriptions ';
		$qry = $qry.'WHERE `author_id` = '.$author_id.' AND `user_id` ='.$user_id;
		//если результат запроса пуст
		$count = count(DB::select($qry));
		if ($count <= 0) {
			//записываем
			$write = 'INSERT INTO tr2022_subscriptions (`author_id`, `user_id`) VALUES (?, ?)';
			DB::insert($write, [$author_id, $user_id]);
		};
		return view('pages.subscribed', [
			'author_id' => $author_id,
		]);
	}
	
}
