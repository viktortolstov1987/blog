<?php

use Illuminate\Support\Facades\Route;
use \App\Http\Controllers\BlogController;
use \App\Http\Controllers\HomeController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//!!!! доступные неаутентифицированным пользователям
Auth::routes();
//маршрут начальной страницы
Route::get('/', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
//при выходе перенаправление сюда же
Route::get('/out', [BlogController::class, 'logout'])->name('out');

//!!!! доступные аутентифицированным пользователям
//маршрут страницы "подписка оформлена"
Route::get('/subscribed/', [BlogController::class, 'subscribed'])->name('subscribed')->middleware('auth');
//маршрут создания публикации
Route::get('/post/create', [BlogController::class, 'newPost'])->name('newPost')->middleware('auth');
//маршрут показа публикации
Route::get('/post/{id}', [BlogController::class, 'getPost'])->name('getPost')->middleware('auth');
//маршрут ленты
Route::get('/feed', [BlogController::class, 'feed'])->name('feed')->middleware('auth');
//маршрут ленты только подписки
Route::get('/subsposts', [BlogController::class, 'subsPosts'])->name('subsPosts')->middleware('auth');
//маршрут сохранения публикации
Route::post('/post/saved', [BlogController::class, 'savePost'])->name('savePost')->middleware('auth');
