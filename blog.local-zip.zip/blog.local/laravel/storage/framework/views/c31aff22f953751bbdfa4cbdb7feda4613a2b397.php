<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="/css/bootstrap.min.css">
</head>
<body>
<div class="container">
	<h1 class="mt-5 mb-4 text-center"><?php echo $__env->yieldContent('title'); ?></h1>
	<?php echo $__env->yieldContent('content'); ?>
</div>
<script src="/js/bootstrap.min.js"></script>
</body>
</html><?php /**PATH C:\wamp64\www\blog.local\laravel\resources\views/layouts/main-layout.blade.php ENDPATH**/ ?>