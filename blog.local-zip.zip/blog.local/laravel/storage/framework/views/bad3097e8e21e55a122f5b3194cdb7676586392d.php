<?php $__env->startSection('title', $post->title); ?>

<?php $__env->startSection('content'); ?>
    <a href="<?php echo e(route('feed')); ?>" class="btn btn-outline-primary mb-4">Вернуться в ленту</a>
    <article>
		<?php echo $post->fulltext; ?>

	</article>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\blog.local\laravel\resources\views/pages/show-post.blade.php ENDPATH**/ ?>