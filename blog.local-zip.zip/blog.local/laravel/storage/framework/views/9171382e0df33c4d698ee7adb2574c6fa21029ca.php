<?php $__env->startSection('title', 'Успешно!'); ?>

<?php $__env->startSection('content'); ?>
    <a href="<?php echo e(route('feed')); ?>" class="btn btn-outline-primary mb-4">Вернуться в ленту</a>
    <article>
		<p>Поздравляем!</p>
		<p>Новый пост размещён</p>
	</article>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\blog.local\laravel\resources\views/pages/save-post.blade.php ENDPATH**/ ?>