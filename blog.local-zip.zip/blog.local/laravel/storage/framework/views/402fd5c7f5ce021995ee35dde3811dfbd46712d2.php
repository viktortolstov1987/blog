<?php $__env->startSection('title', 'Новый пост'); ?>

<?php $__env->startSection('content'); ?>
    <form method="post" action="<?php echo e(route('savePost')); ?>">
		<!-- защита от межсайтовых атак // -->
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <input type="text" class="form-control" name="title" placeholder="Заголовок" required>
        </div>
        <div class="form-group">
            <textarea class="form-control" name="descr" placeholder="Краткое описание" required></textarea>
        </div>
        <div class="form-group">
            <textarea class="form-control" name="fulltext" placeholder="Полный текст" rows="7" required></textarea>
        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-primary">Сохранить</button>
        </div>
    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\blog.local\laravel\resources\views/pages/new-post.blade.php ENDPATH**/ ?>