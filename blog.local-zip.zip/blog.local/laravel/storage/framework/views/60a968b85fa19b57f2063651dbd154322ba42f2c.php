<?php $__env->startSection('title', 'Лента'); ?>

<?php $__env->startSection('content'); ?>

	<!-- создание поста и выход // -->
	<div class="btn-group mb-4" role="group">
		<a href="<?php echo e(route('newPost')); ?>" class="btn btn-outline-primary">Написать пост</a>
		&nbsp;
		<a href="<?php echo e(route('feed')); ?>" class="btn btn-outline-primary">Вся лента</a>
		&nbsp;
		<a href="<?php echo e(route('subs')); ?>" class="btn btn-outline-primary">Подписки</a>
		&nbsp;
		<a href="<?php echo e(route('out')); ?>" class="btn btn-outline-primary">Выйти</a>
	</div>
	<!-- цикл обработки постов // -->
	<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php
			$link = mysqli_connect('localhost', 'root', 'PASSWORD', 'tolstovbd');
		?>
		<div class="card mb-4">
			<div class="card-header">
				<a href="#">Автор: 
				<?php
					$author_id = $post->author_id;
					$qry = 'SELECT id, name FROM tr2022_users WHERE id = '.$author_id;
					$result = $link->query($qry);
					if($result){
						$result->data_seek(0);
						$row = $result->fetch_row();
						$name = $row[1];
						echo $name;
						$result->close();
					} else {
						echo $post->author_id;
					}
				?>
				</a>
				&nbsp;
				<a href="#">
					<!-- вывод слова "Подписаться" или "Вы подписаны" // -->
						Подписаться
				</a>
			</div>
			<div class="card-body">
				<h5 class="card-title"><?php echo e($post->title); ?></h5>
				<p class="card-text"><?php echo e($post->descr); ?></p>
				<a href="<?php echo e(route('getPost', $post->id )); ?>" class="btn btn-primary">Подробнее</a>
			</div>
		</div>
		<?php
			mysqli_close($link);
		?>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\blog.local\laravel\resources\views/pages/feed.blade.php ENDPATH**/ ?>