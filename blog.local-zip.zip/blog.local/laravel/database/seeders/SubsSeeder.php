<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class SubsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
		for($i = 1; $i < 20; $i++){
			DB::table('subscriptions')->insert([
				'author_id' => rand(1, 10),
				'user_id' => rand(1, 10),
			]);
		}
    }
}
