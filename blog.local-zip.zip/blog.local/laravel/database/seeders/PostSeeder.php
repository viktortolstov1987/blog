<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class PostSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
		for($i = 1; $i < 20; $i++){
			DB::table('posts')->insert([
				'id' => $i,
				'author_id' => rand(1, 10),
				'title' => 'Пост '.$i,
				'descr' => 'Описание поста '.$i,
				'fulltext' => '<p>Абзац, полный текста. В данном случае он просто показывает. что он тут есть. Данное веб-приложение написано для компании "Трия". Разработал кандидат на вакантную должность Толстов Виктор Андреевич, эксперт WSR в компетенции 17 &qout;Веб-технологии&qout;'.$i.'</p>',
			]);
		}
    }
}
