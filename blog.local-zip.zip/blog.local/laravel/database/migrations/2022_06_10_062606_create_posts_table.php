<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePostsTable extends Migration
{
    /**
     * Run the migrations. Действия при созадании таблицы
     *
     * @return void
     */
    public function up()
    {
        Schema::create('posts', function (Blueprint $table) {
            $table->bigIncrements('id')->unsigned();
			$table->bigInteger('author_id')->unsigned();
			$table->string('title', 200);
			$table->text('descr');
			$table->text('fulltext');
			$table->string('slug')->unique();
            $table->timestamps();
			//внешний ключ
			$table->foreign('author_id')->references('id')->on('users');
        });
    }

    /**
     * Reverse the migrations. Действия при удалении таблицы
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('posts');
    }
}
