@extends('layouts.main-layout')

@section('title', 'Новый пост')

@section('content')
    <form method="post" action="{{ route('savePost') }}">
		<!-- защита от межсайтовых атак // -->
        @csrf
        <div class="form-group">
            <input type="text" class="form-control" name="title" placeholder="Заголовок" required>
        </div>
        <div class="form-group">
            <textarea class="form-control" name="descr" placeholder="Краткое описание" required></textarea>
        </div>
        <div class="form-group">
            <textarea class="form-control" name="fulltext" placeholder="Полный текст" rows="7" required></textarea>
        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-primary">Сохранить</button>
        </div>
    </form>

@endsection