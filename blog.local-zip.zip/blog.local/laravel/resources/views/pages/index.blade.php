@extends('layouts.main-layout')

@section('title', 'Ваши подписки')

@section('content')
	<div class="btn-group mb-4" role="group">
	@foreach($authors as $author)
		<a href="#" class="btn btn-outline-primary">Автор: {{ $author->name }}</a>
	@endforeach
    </div>
	<!-- создание поста // -->
	<div class="btn-group mb-4" role="group">
		<a href="{{ route('newPost') }}" class="btn btn-outline-primary">Написать пост</a>
	</div>
	<!-- цикл обработки постов // -->
	@foreach($posts as $post)
		@php
			$link = mysqli_connect('localhost', 'root', 'PASSWORD', 'tolstovbd');
		@endphp
		<div class="card mb-4">
			<div class="card-header">
				<a href="#">Автор: 
				@php
					$author_id = $post->author_id;
					$qry = 'SELECT id, name FROM tr2022_users WHERE id = '.$author_id;
					$result = $link->query($qry);
					if($result){
						$result->data_seek(0);
						$row = $result->fetch_row();
						$name = $row[1];
						echo $name;
						$result->close();
					} else {
						echo $post->author_id;
					}
				@endphp
				</a>
				&nbsp;
				<a href="#">Подписаться</a>
			</div>
			<div class="card-body">
				<h5 class="card-title">{{$post->title}}</h5>
				<p class="card-text">{{$post->descr}}</p>
				<a href="{{ route('getPost', $post->id ) }}" class="btn btn-primary">Подробнее</a>
			</div>
		</div>
		@php
			mysqli_close($link);
		@endphp
	@endforeach

@endsection