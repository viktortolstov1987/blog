@extends('layouts.main-layout')

@section('title', 'Лента')

@section('content')

	<!-- группа кнопок управления // -->
	<div class="btn-group mb-4" role="group">
		<a href="{{ route('newPost') }}" class="btn btn-outline-primary">Написать пост</a>
		&nbsp;
		<a href="{{ route('feed') }}" class="btn btn-outline-primary">Вся лента</a>
		&nbsp;
		<a href="{{ route('subsPosts') }}" class="btn btn-outline-primary">Подписки</a>
		&nbsp;
		<a href="{{ route('out') }}" class="btn btn-outline-primary">Выйти</a>
	</div>
	<!-- группа кнопок авторов // -->
	<div class="btn-group mb-4" role="group">
	@foreach($authors as $author)	
		<a href="#" class="btn btn-outline-primary">{{ $author->name }}</a>
	@endforeach
	</div>
	<!-- цикл обработки постов // -->
	@foreach($posts as $post)
		@php
			$link = mysqli_connect('localhost', 'root', 'PASSWORD', 'tolstovbd');
		@endphp
		<div class="card mb-4">
			<div class="card-header">
				<a href="#">Автор: 
				@php
					$author_id = $post->author_id;
					$qry = 'SELECT id, name FROM tr2022_users WHERE id = '.$author_id;
					$result = $link->query($qry);
					if($result){
						$result->data_seek(0);
						$row = $result->fetch_row();
						$author_id = $row[0];
						$name = $row[1];
						echo $name;
						$result->close();
					} else {
						echo $post->author_id;
					}
				@endphp
				</a>
				<div>
					<!-- кнопка "Подписаться // -->
					<form method="get" action="{{ route('subscribed') }}">
						<!-- здесь id автора определяется корректно // -->
						<input type="text" name="author_id" value="{{ $post->author_id }}" hidden>
						<button type="submit" class="btn btn-primary">Подписаться</button>
					</form>
					<!-- a href="{{ route('subscribed', $post->author_id) }}">Подписаться</button // -->
				</div>
			</div>
			<div class="card-body">
				<h5 class="card-title">{{$post->title}}</h5>
				<p class="card-text">{{$post->descr}}</p>
				<a href="{{ route('getPost', $post->id) }}" class="btn btn-primary">Подробнее</a>
			</div>
		</div>
		@php
			mysqli_close($link);
		@endphp
	@endforeach

@endsection