@extends('layouts.main-layout')

@section('title', $post->title)

@section('content')
    <a href="{{ route('feed') }}" class="btn btn-outline-primary mb-4">Вернуться в ленту</a>
    <article>
		{!! $post->fulltext !!}
	</article>

@endsection